class ThanksController < ApplicationController

  def index
  end


end