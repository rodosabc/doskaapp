require 'test_helper'

class FaqItemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
