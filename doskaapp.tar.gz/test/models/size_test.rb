require 'test_helper'

class SizeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
