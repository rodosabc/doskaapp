require 'test_helper'

class NewsItemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
