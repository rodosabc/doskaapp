require 'test_helper'

class ContactItemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
