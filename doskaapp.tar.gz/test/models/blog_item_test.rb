require 'test_helper'

class BlogItemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
